import { applicationElement, loginElement, logoutElement, registerElement, url,Acceuil } from "./config.js"
import { viderLogin, viderRegister } from "./main.js";



export const authentifier=(login,pwd)=>{
    const dataToSend = {login:login,pwd:pwd}
    fetch(url+"/users/login",{
        method:"POST",
        body:JSON.stringify(dataToSend),
        headers:{
            'Content-Type': 'application/json'
        }
    }).then(res=>{
        if(res.ok)
        {
            viderLogin();
            res.json().then(data=>{
                const {token,name}=data;
                Acceuil.innerText="Welcome "+name+" to your Memo"
                localStorage.setItem('isLoggedIn', 'true');
                applicationElement.classList.remove("hidden")
                logoutElement.children[0].innerText="Logout(" +name+")"
                registerElement.classList.add("hidden")

                // insertion du JWT dans le local storage
                localStorage.setItem("token",token);
                 window.location="#welcome"
                 loginElement.classList.add("hidden")
                 logoutElement.classList.remove("hidden")
                 viderLogin();
            }).catch(err=>alert(err))
        }
        else{
            alert("echec d'authentification")
        }
    })
    .catch(err=>console.log(err));
}



export const logout=()=>{
    fetch(url+"/users/logout",{ 
        method:"POST"
    }).then(res=>{
        if(res.ok)
        {
            localStorage.setItem('isLoggedIn', 'false');
            Acceuil.innerText="Welcome"
            window.location="#welcome"
            localStorage.removeItem("token");
            loginElement.classList.remove("hidden")
            logoutElement.classList.add("hidden")
            registerElement.classList.remove("hidden")
            applicationElement.classList.add("hidden") 
        }
        else{
            alert("error dans le logout")
        }
    })
    .catch(err=>alert(err));
}

export const register =(email,name,pwd,pwd2)=>{
    const dataToSend={
        login:email,
        name:name,
        pwd:pwd,
        pwd2:pwd2
    }
    fetch(url+"/users/register",{
        method:"POST",
        body:JSON.stringify(dataToSend),
        headers:{
            'Content-Type': 'application/json'
    }}).then(res=>{
        if(res.ok) {
            alert("success");
            window.location="#login"
            viderRegister();
        }else{
            res.json()
            .then(data=>{
                const {message}=data;
                alert(message)
            })
            .catch(err=>{ alert("erreur");
                        console.log(err);
                    })
        }
    })
    .catch(err=>{
        alert("erreur");
        console.log(err);
    });

}

