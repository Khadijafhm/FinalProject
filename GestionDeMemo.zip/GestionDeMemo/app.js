const express = require("express")
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken")
const cors = require('cors');
const { UserRouter } = require("./routes/users");
const { memosRouter } = require("./routes/memos");


require('dotenv').config()

mongoose.connect(process.env.chaine_connection)
.then(()=>console.log("connected to mongoo atlass"))
.catch(err=>console.log(err))

const app = express();

app.use(cors());

app.use(express.static("./public"))
app.use(express.json());

app.use("/users",UserRouter)
app.use("/memos",memosRouter)

app.use("", (req, res, next) => {
    
    try {
    const token = req.headers.authorization;
    if (!token)
    return res.status(401).json({ message: "Authentification failed, No token provided" });
    const bearer = token.split(" ");
    if (bearer.length !== 2)
    return res.status(401).json({ message: "Authentification failed, Invalid token format" });
    const decoded = jwt.verify(bearer[1], process.env.jwtsecret);
    req.userInfo = decoded;
    next();
    } catch { err=>res.status(500).json({message:err})}
})

app.use("/memos",memosRouter)


const port =process.env.port || 3000
app.listen(port, ()=>{
    console.log('server listening on port : ',port)
})

