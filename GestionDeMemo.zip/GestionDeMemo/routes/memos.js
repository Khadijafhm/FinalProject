const express= require('express')
const {Memo} = require('../models/memo');
const jwt = require("jsonwebtoken");
const { User } = require('../models/user');
const router = express.Router();

//middleware
//check if you are authorized
router.use("", (req, res, next) => {
    try {
    const token = req.headers.authorization;
    if (!token)
    return res.status(401).json({ message: "Authentification failed, No token provided" });
    const bearer = token.split(" ");
    if (bearer.length !== 2)
    return res.status(401).json({ message: "Authentification failed, Invalid token format" });
    const decoded = jwt.verify(bearer[1], process.env.jwtsecret);
    req.userInfo = decoded;
    next();
    } catch { err=>res.status(500).json({message:err})}
})
// ajouter
router.post("",async (req,res)=>{
    // recuperation des donnees envoyees
   const {date, content} =  req.body
   // verification
   if(!date || !content)
    return res.status(400).json({message:"date and content are required"})
    // creer une instance du model
    const memo=new Memo({
        date:date,
        content:content
    })
    const login =  req.userInfo.login;
    try{
    const dataMemo =  await memo.save()
    const user=await User.findOne({login:login})
    user.memos.push(dataMemo)
    const data = await user.save();
    res.json(data.memos[data.memos.length-1]);
    }catch(err)
    {
        res.status(500).send({message:err})
    }
})

// lister memo
router.get("",async (req,res)=>{
    const login =  req.userInfo.login;
    const user=await User.findOne({login:login})
    const nbr = req.query.nbr || user.memos.length
    const dataToSend=user.memos.filter((elem,index)=>index<nbr)
    res.json(dataToSend)
  
})

//supprimer memo
router.delete("/:idMemo",async (req,res)=>{
    
    const idMemo = req.params.idMemo
    const login =  req.userInfo.login;
    try{
    const user= await User.findOne({login:login})
    if(!user.memos.find(memo=>memo._id==idMemo))
        throw ("not allowed sorry")
        
    // suppression depuis la collection des memos
    await Memo.findByIdAndDelete(idMemo)
    user.memos.remove({_id:idMemo})
    await user.save();
    res.json({message:'delete with success'})
    }
    catch(err){
        res.status(500).send({message:err})
    }
})

router.put("/:idMemo",async (req,res)=>{

    const idMemo = req.params.idMemo
    const login =  req.userInfo.login;
    try{
    const user= await User.findOne({login:login})
    if(!user.memos.find(memo=>memo._id==idMemo))
        throw ("not allowed sorry")
        
    // suppression depuis la collection des memos
    await Memo.findByIdAndDelete(idMemo)
    user.memos.remove({_id:idMemo})
    const memo=new Memo({
        content:req.body.content
    })

    const dataMemo =  await memo.save()
    user.memos.push(dataMemo)
    const data = await user.save();
    res.json(data.memos[data.memos.length-1]);
    }
    catch(err){
        res.status(500).send({message:err})
    }
   }
)

module.exports.memosRouter= router;