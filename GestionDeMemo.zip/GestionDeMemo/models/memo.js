const { default: mongoose } = require("mongoose");

const schema = new mongoose.Schema({
    date:{
        type: Date,
        default: Date.now 
    },
    content:{
        type:String,
        required: true
    }
})
const Memo = mongoose.model("memos",schema)

module.exports={schemaMemo:schema,Memo:Memo}